﻿namespace Bloxstrap.Models.APIs.Roblox
{
    // lmao its just one property
    public class UniverseIdResponse
    {
        [JsonPropertyName("universeId")]
        public long UniverseId { get; set; }
    }
}
